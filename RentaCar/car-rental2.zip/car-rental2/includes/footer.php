</main>

<footer>
    <!-- Add footer content, copyright information, etc. -->
    <p>&copy; <?php echo date("Y"); ?> Car Rental</p>
</footer>

<!-- Add any additional JavaScript at the end of the body if needed -->

</body>
</html>

