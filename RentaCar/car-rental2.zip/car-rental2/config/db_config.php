<?php

define('DB_HOST', 'localhost');
define('DB_PORT', '3307');
define('DB_NAME', 'rentacar');
define('DB_USER', 'root');
define('DB_PASSWORD', '');

?>
