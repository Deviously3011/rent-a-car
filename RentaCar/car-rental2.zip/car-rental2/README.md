--the file structure for this project 
car-rental/
|-- assets/
|   |-- css/
|   |   |-- style.css
|   |-- js/0 
|   |-- img/
|-- classes/
|   |-- Database.php
|   |-- User.php
|   |-- Car.php
|   |-- Admin.php
|   |-- RentalCalculator.php
|-- config/
|   |-- db_config.php
|-- includes/
|   |-- header.php
|   |-- footer.php
|-- pages/
|   |-- admin_pages/
|   |   |-- admin-dashboard.php
|   |   |-- edit-car.php
|   |   |-- edit-user.php
|   |   |-- manage-users.php
|   |   |-- view-rentals..php
|   |-- login_pages/
|   |   |-- login.php
|   |   |-- logout.php
|   |   |-- signup.php  
|   |-- car_pages/
|   |   |-- car_detail_template.php
|   |   |-- car_details.php
|   |-- renting/
|   |   |-- checkout.php
|   |   |-- factuur.php
|   |   |-- purchase_succesful.php
|   |-- user-pages/
|   |   |-- dashboard.php
|-- .gitignore
|-- index.php
|-- README.md
|-- admin create.php 
